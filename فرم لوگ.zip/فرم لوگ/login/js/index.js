let modal = document.getElementById("modal-container");
let caption = document.getElementById("caption");
let loginPanel = document.getElementById("loginPanel");
let loginbtn = document.getElementById("loginbtn");
let password = document.getElementById("password");
let username = document.getElementById("username");
let validationError = document.getElementById("validationError");
let passError = document.getElementById("pass-error");
let userError = document.getElementById("user-error");
let SpecialCharacter = document.getElementById("Special_character");
let regex = new Array();
let passed = 0;
let handPoint = document.getElementById("loading");



function login() {
    modal.style.display = "block";
    loginPanel.style.display = "none";
    caption.innerHTML = "به صفحه ورود خوش آمدید";
}

function closePage() {
    modal.style.display = "none";
    loginPanel.style.display = "block";

}
function closeIt() {
    validationError.style.display="none";
}
onclick = function (evt) {
    if (evt.target == modal) {
        modal.style.display = "none";
        loginPanel.style.display = "block";
    }
}
function logoutbtn(){
        loginPanel.style.display = "block";
        logoutPanel.style.display = "none";
        loginbtn.style.display = "block";
}


        function loadhand() {
            setTimeout(function () {
                handPoint.className = handPoint.className.replace("far fa-hand-point-right",
                    "fas fa-hand-point-right");
            }, 1000);
            setTimeout(function () {
                handPoint.className = handPoint.className.replace("fas fa-hand-point-right",
                    "far fa-hand-point-right");
            }, 2000);
            
        }
        loadhand();
        setInterval(loadhand, 2000);
function validation() {

    if (username.value === '') {
        userError.innerHTML = 'نام کاربری خود را وارد نمایید';
        username.style.borderColor = "red"
        userError.style.display = "block"

    }
    if (password.value === '') {
        passError.innerHTML = 'رمز عبور را وارد نمایید';
        password.style.borderColor = "red";
        passError.style.display = "block";

    } else if (password.value.length < 8 || username.value.length < 3) {
        validationError.style.display = "block";
        passError.style.marginBottom = "30px";
        userError.style.marginBottom = "15px";

    } else {
        modal.style.display = "none";
        loginPanel.style.display = "none";
        logoutPanel.style.display = "block";
        loginbtn.style.display = "none";
        username.style.borderColor = "red";
        window.alert("سلام به پنل کاربری خود خوش آمدید !!");
        // passError.style.marginBottom = "20px";
        // userError.style.marginBottom = "8px";
    }

}

function go() {
    if (username.value.length < 3) {
        username.style.borderColor = "red";
        userError.style.display = "block";
        userError.innerHTML = 'نام کاربری معتبر نمیباشد';

    } else if (password.value.length < 8) {
        password.style.borderColor = "red";
        passError.style.display = "block";
        passError.innerHTML = 'رمز عبور شما باید بیش از 8 حرف یا عدد باشد';
    }
    // if (validationError.style.display == "block" || SpecialCharacter.style.display == "block"){
    //     passError.style.bottom = "25px!important";
    //     // userError.style.marginBottom = "25px";
    // }

}

function onkey(user) {
    regex.push("[$@$!%*#?&]");
    for (let i = 0; i < regex.length; i++) {
        if (new RegExp(regex[i]).test(user) && username.value.length >= 3) {
            passed++;

            username.style.borderColor = "red";
            SpecialCharacter.style.display = "block";
            SpecialCharacter.style.color = "red";
            passError.style.marginBottom = "-4px";

        }else{
         username.style.borderColor = "gray";
         userError.style.display = "none";
         SpecialCharacter.style.display = "none";
         passError.style.marginBottom = "20px";
        }
    }
    //ino ta inja dorost krdm
    //frda sob bara errorvalidation yezabdar bezaram
    // if (username.value.length >= 3) {
    //     username.style.borderColor = "gray";
    //     userError.style.display = "none";
    // } 

     if (password.value.length >= 8) {
        password.style.borderColor = "gray";
        passError.style.display = "none";
    } else {
        passError.style.marginBottom = "20px";
    }

    
}